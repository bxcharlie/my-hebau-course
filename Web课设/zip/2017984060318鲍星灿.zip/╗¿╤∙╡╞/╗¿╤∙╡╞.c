#include <reg51.h> 
void Delayms (unsigned int x) {
	unsigned int i, j;
	for (i = x; i > 0; i--)
	for (j = 110; j > 0; j--);
}
void main() {
	unsigned int i;
  unsigned char temp;
	while(1) {
		temp = 0x01;
		for (i = 0; i < 8; i++) {
			P1 = ~temp;
			Delayms(100);
			temp <<= 1;
		}
		temp = 0x80;
		for (i = 0; i < 8; i++) {
			P1 = ~temp;
			Delayms(100);
			temp >>= 1;
		}
		temp = 0xfe;
		for (i = 0; i < 8; i++) {
			P1 = temp;
			Delayms(100);
			temp <<= 1;
		}
		temp = 0x7f;
		for (i = 0; i < 8; i++) {
			P1 = temp;
			Delayms(100);
			temp >>=1;
		}
	}
}